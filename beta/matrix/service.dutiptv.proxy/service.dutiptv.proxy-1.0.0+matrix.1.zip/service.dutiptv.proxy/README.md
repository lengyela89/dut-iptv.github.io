# service.dutiptv.proxy

### About

-Proxy for use with Dut-IPTV addons 

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-Team Kodi for Kodi