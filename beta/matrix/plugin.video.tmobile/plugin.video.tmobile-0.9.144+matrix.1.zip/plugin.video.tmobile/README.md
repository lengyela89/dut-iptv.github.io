# plugin.video.tmobile

### About

-Watch T-Mobile Anywhere Live TV and content from anywhere in the EU

### Features

-Unofficial 3rd Party T-Mobile Anywhere plugin for Kodi

-Watch 35 Live TV channels

-Replay programs from the last 7 days from all channels in your subscription

-Search Content

-Supports watching TV and listening to Radio using the PVR IPTV Simple Addon (through the separate Dut-IPTV Simple IPTV Connector)

-Supports Catchup using PVR IPTV Simple Addon in Kodi 19 (through the separate Dut-IPTV Simple IPTV Connector addon)

### Required

-T-Mobile TV Subscription (not free)

-Kodi 18 or higher with Widevine Support (free)

### To-Do

-

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-peak3d for Inputstream Adaptive

-Team Kodi for Kodi