from resources.lib.base.l3.language import _

CONST_BASE_URL = ''
CONST_BASE_HEADERS = {}
CONST_DEFAULT_API = ''
CONST_IMAGE_URL = ''
CONST_ONLINE_SEARCH = False
CONST_VOD_CAPABILITY = []
CONST_WATCHLIST = False