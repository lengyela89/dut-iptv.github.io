# plugin.executable.dutiptv

### About

-Create a merged Playlist/EPG using the Dut-IPTV addons for use in Simple IPTV

### Features

-Supports watching TV and listening to Radio using the PVR IPTV Simple Addon

-Supports Catchup using PVR IPTV Simple Addon in Kodi 19

### Required

-Two or more subscriptions to CanalDigitaal, KPN/Telfort/XS4ALL, NLZiet, T-Mobile or Ziggo (not free)

-Kodi 18 or higher with Widevine Support (free)

### To-Do

-

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-Team Kodi for Kodi