from resources.lib.service import main
main()