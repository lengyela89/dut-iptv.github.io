from resources.lib.base.l8.menu import plugin
plugin.dispatch(sys.argv[2])